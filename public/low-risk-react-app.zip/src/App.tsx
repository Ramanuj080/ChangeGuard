import React, { useState } from 'react';

export function App() {
  const [email, setEmail] = useState('');
  return (
    <div className="container">
      <h1>Customer Account Profile</h1>
      <input 
        type="email" 
        placeholder="Optional Customer Email" 
        value={email} 
        onChange={e => setEmail(e.target.value)} 
      />
    </div>
  );
}
