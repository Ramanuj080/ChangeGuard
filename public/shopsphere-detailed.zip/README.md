# ShopSphere
Detailed ecommerce microservices demo for ChangeGuard.
