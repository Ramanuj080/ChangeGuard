# Architecture
Gateway -> Order -> Payment -> Fraud; Order -> Inventory; Payment -> Analytics; Order -> Notification.
