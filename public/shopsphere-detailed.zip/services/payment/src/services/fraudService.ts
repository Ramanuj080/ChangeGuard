export async function score(){return 0}
