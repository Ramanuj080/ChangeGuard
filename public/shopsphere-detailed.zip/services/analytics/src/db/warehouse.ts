export const warehouse={insert:async()=>{}};
