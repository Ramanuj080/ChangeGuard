import { inventoryService } from '../services/inventoryService';
