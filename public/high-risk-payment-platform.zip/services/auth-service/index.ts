import express from 'express';
const router = express.Router();

router.post('/v1/auth/login', (req, res) => {
  res.json({ token: 'jwt_mock_token' });
});

export default router;
