import express from 'express';
const router = express.Router();

router.get('/v1/orders/:id', (req, res) => {
  res.json({ orderId: req.params.id, status: 'PROCESSING' });
});

router.post('/v1/orders/checkout', (req, res) => {
  // Calls payment service
  res.json({ checkoutId: 'chk_999' });
});

export default router;
