import express from 'express';
import { orderRoutes } from './services/orders';
const app = express();
app.use('/api/orders', orderRoutes);
app.listen(8080);
