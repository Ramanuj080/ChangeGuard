import express from 'express';
export const orderRoutes = express.Router();
orderRoutes.get('/', (req, res) => res.json({ orders: [] }));
orderRoutes.post('/checkout', (req, res) => res.json({ status: 'success' }));
