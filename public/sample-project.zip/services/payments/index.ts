import Stripe from 'stripe';
const stripe = new Stripe('key');
export async function processPayment(amount: number) {
  return stripe.charges.create({ amount });
}
