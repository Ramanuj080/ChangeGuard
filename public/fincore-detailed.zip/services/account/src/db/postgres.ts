export const postgres={query:async()=>[]};
