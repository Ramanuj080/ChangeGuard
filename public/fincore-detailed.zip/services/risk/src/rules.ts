export const rules=['velocity','amount','location'];
