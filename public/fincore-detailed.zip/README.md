# FinCore Banking Platform
Detailed banking microservices demo.
