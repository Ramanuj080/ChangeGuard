Mobile/Web -> Gateway -> Transfer -> Account/Risk/Ledger -> Notification. Ledger -> events -> Analytics.
