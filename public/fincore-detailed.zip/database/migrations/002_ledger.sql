CREATE TABLE ledger_entries(id UUID PRIMARY KEY, account_id UUID, amount NUMERIC);
