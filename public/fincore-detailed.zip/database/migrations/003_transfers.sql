CREATE TABLE transfers(id UUID PRIMARY KEY, account_id UUID, status TEXT);
