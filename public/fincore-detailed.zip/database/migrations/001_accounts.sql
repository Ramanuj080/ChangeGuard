CREATE TABLE accounts(id UUID PRIMARY KEY, customer_id UUID, status TEXT);
