Web -> Gateway -> Tracking -> Routing/ETA/DB. Gateway -> Pricing. Workers -> Carrier/Warehouse/Notifications. Maps supports routing.
