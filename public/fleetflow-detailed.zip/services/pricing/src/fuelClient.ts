export async function fuelPrice(){}
