CREATE INDEX idx_shipments_status ON shipments(status);
