CREATE TABLE shipments(id UUID PRIMARY KEY, status TEXT, carrier_id UUID);
