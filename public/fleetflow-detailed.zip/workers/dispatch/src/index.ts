import { dispatcher } from './dispatcher';
